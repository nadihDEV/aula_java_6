import java.util.Scanner;


public class TesteVingadores {
    public static void main(String[] args) {

        Vingadores thor = new Vingadores();
        Scanner sc = new Scanner(System.in);
        //Vingadores thor = new Vingadores();
        System.out.println("Digite o nome do seu Vingador");
        thor.nome = sc.nextLine();

        //sc.nextLine();// consumir uma quebra de linha
        System.out.println("Digite o poder do seu Vingador");
        thor.poder = sc.nextLine();

        System.out.println("Digite a idade do seu Vingador");
        thor.idade = sc.nextInt();

        System.out.println("Digite a altura do seu Vingador");
        thor.altura = sc.nextDouble();

        System.out.println("Digite a origem do seu Vingador");
        thor.origem = sc.nextLine();

        sc.nextLine();// consumir uma quebra de linha
        System.out.println("É humano? Digite S ou N");
        char resp = sc.nextLine().charAt(0);
        switch (resp){
            case 'S':
                thor.isHumano  = true;
                break;
            case 's':
                thor.isHumano  = true;
                break;
            case 'N':
                thor.isHumano  = false;
                break;
            case 'n':
                thor.isHumano  = false;
                break;
        }
    }
}