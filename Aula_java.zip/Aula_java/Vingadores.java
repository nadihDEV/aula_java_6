//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Vingadores {

    String nome;
    String poder;
    int idade;
    double altura;
    String origem;
    boolean isHumano;


    void bater(){
        System.out.println(Vingadores.this.nome + " jab + direto de esquerda tipo poatan");
    }

    void berrar(){
        System.out.println(Vingadores.this.nome + "AAAAAAAAAAAAAAAAAAAAAAAA");
    }

    void invocar(){
        System.out.println(Vingadores.this.nome +" Invocação do mal 2 ");
    }

}
